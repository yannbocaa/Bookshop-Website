<!DOCTYPE html>
<html lang="pl">
<head>
<?php include 'PHP\headpartTs.php'; ?>

 </head>
 <body>
<header>
<?php include 'PHP\headerTs.php'; ?>
</header>
<article>
<?php include 'PHP\articleTs.php'; ?>
</article>
<footer>
<?php include 'PHP\footerTs.php'; ?>
</footer>
</body>
</html>