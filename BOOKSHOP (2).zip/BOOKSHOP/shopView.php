<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Books</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>The Happy Student Bookstore</h1>
        <h3>View Books</h3>
    </header>

    <main>
        <h2>List of Books</h2>
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Genre</th>
                    <th>Publication Year</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "bookstore_db";

                $conn = new mysqli($servername, $username, $password, $dbname);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "SELECT title, author, genre, publication_year FROM books";

                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["title"] . "</td>";
                        echo "<td>" . $row["author"] . "</td>";
                        echo "<td>" . $row["genre"] . "</td>";
                        echo "<td>" . $row["publication_year"] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='4'>No books found.</td></tr>";
                }

                $conn->close();
                ?>
            </tbody>
        </table>
    </main>

    <footer>
        <nav>
            <ul>
            <li><a href="shopStartTSY.php">Main page</a></li>
                <li><a href="shopView.php">View books</a></li>
                <li><a href="shopAdd.php">Add a book</a></li>
                <li><a href="shopDelete.php">Delete a book</a></li>
                <li><a href="addReviews.php">Add reviews</a></li>
                <li><a href="viewReviews.php">View reviews</a></li>
            </ul>
        </nav>
        <h6>Winter 2022</h6>
    </footer>
</body>
</html>
