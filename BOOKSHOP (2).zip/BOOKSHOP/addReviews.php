<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Review</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>The Happy Community Library</h1>
        <h3>Add Review</h3>
    </header>
    <main>
        <form action="processReview.php" method="post">
            <label for="book-title">Book Title:</label>
            <input type="text" id="book-title" name="book-title" required>

            <label for="reviewer-name">Your Name:</label>
            <input type="text" id="reviewer-name" name="reviewer-name" required>

            <label for="rating">Rating:</label>
            <input type="number" id="rating" name="rating" min="1" max="5" required>

            <label for="review-text">Review:</label>
            <textarea id="review-text" name="review-text" rows="5" required></textarea>

            <button type="submit">Submit Review</button>
        </form>
    </main>
    <footer>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="shopView.php">View Books</a></li>
                <li><a href="shopAdd.php">Add a Book</a></li>
                <li><a href="shopDelete.php">Delete a Book</a></li>
                <li><a href="viewUsers.php">View Users</a></li>
                <li><a href="viewReviews.php">View Reviews</a></li>
            </ul>` 
        </nav>
        <h6>Terrence, Yann and Revas Project</h6>
        <h5><a href="login.php">LOG OUT</a></h5> 
    </footer>
</body>
</html>
