<?php
// Include database connection
require_once 'db_connection.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $bookTitle = $_POST['book-title'];
    $reviewerName = $_POST['reviewer-name'];
    $rating = $_POST['rating'];
    $reviewText = $_POST['review-text'];

    // Prepare and execute the SQL statement to insert the review into the database
    $sql = "INSERT INTO book_reviews (book_title, reviewer_name, rating, review_text) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssis", $bookTitle, $reviewerName, $rating, $reviewText);

    if ($stmt->execute()) {
        // Review successfully added to the database
        echo "Review submitted successfully! You can view other reviews <a href='viewReviews.php'>HERE</a>";
    } else {
        // Error occurred while adding the review
        echo "Error: " . $conn->error;
    }

    // Close statement and database connection
    $stmt->close();
    $conn->close();
} else {
    // If the form is not submitted, redirect the user to the addReview.php page
    header("Location: addReview.php");
    exit();
}
?>
