<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>Register</h1>
    </header>

    <main>
        <form action="registerProcess.php" method="post">
            <label for="username">Username:</label><br>
            <input type="text" id="username" name="username" required><br><br>
            
            <label for="password">Password:</label><br>
            <input type="password" id="password" name="password" required><br><br>
            
            <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            
            <input type="submit" value="Register">
        </form>
    </main>

    <footer>
        <h6>Terrence, Yann and Revas Project</h6>
        <h5><a href="login.php">LOG OUT</a></h5> 
    </footer>
</body>
</html>
