<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add a Book</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>The Happy Community Library</h1>
        <h3>Add a New Book</h3>
    </header>

    <main>
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Database connection parameters
            $servername = "localhost"; 
            $username = "root"; 
            $password = ""; 
            $dbname = "bookstore_db"; 

            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Retrieve form data
            $title = $_POST['title'];
            $author = $_POST['author'];
            $genre = $_POST['genre'];
            $publication_year = $_POST['publication_year'];

            // Prepare SQL statement to insert a new book into the database
            $sql = "INSERT INTO books (title, author, genre, publication_year) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);

            // Bind parameters and execute the statement
            $stmt->bind_param("sssi", $title, $author, $genre, $publication_year);
            $result = $stmt->execute();

            // Check if the insertion was successful
            if ($result === TRUE) {
                echo "<p class='success'>New book added successfully!</p>";
            } else {
                echo "<p class='error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
            }

            // Close the prepared statement and database connection
            $stmt->close();
            $conn->close();
        }
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <label for="title">Title:</label><br>
            <input type="text" id="title" name="title" required><br><br>

            <label for="author">Author:</label><br>
            <input type="text" id="author" name="author" required><br><br>

            <label for="genre">Genre:</label><br>
            <input type="text" id="genre" name="genre"><br><br>

            <label for="publication_year">Publication Year:</label><br>
            <input type="text" id="publication_year" name="publication_year"><br><br>

            <input type="submit" value="Add Book">
        </form>
    </main>

    <footer>
        <nav>
            <ul>
            <li><a href="ShopStartTSY.php">Home</a></li>
                <li><a href="shopView.php">View Books</a></li>
                <li><a href="shopAdd.php">Add a Book</a></li>
                <li><a href="shopDelete.php">Delete a Book</a></li>
                <li><a href="viewUsers.php">View Users</a></li>
                <li><a href="addReviews.php">Add reviews</a></li>
                <li><a href="viewReviews.php">View reviews</a></li>

            </ul>
        </nav>
        <h6>Terrence, Yann and Revas Project</h6>
        <h5><a href="login.php">LOG OUT</a></h5> 
    </footer>
</body>
</html>
