<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>WELCOME TO OUR BOOKSHOP</h2><br>
    <h3>We have books available as well as their reviews! </h3>
    <div class="container">
        <h2>Login</h2>
        <form action="loginProcess.php" method="post">
            <div class="form-group">
                <label for="username">Username/Email:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">Login</button>
            <a href="register.php">No account? Register here</a>
        </form>
    </div>
</body>
</html>
