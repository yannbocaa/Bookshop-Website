<?php
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the username/email and password are provided
    if (isset($_POST["username"]) && isset($_POST["password"])) {
        // Collect username/email and password from the form
        $username_email = $_POST["username"];
        $password = $_POST["password"];
        
    
        $servername = "localhost";
        $dbusername = "root";
        $dbpassword = "";
        $dbname = "bookstore_db";

        // Create a connection
        $conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Query to check if the username/email and password match
        $sql = "SELECT * FROM users WHERE (username='$username_email' OR email='$username_email')";
        $result = $conn->query($sql);

        // If a row is returned, check the password
        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                // Set session variables
                $_SESSION["username"] = $username_email;

                // Redirect to the homepage or any other page after successful login
                header("Location: shopStartTSY.php");
                exit();
            } else {
                // If password doesn't match, show error message
                echo "Invalid password.";
            }
        } else {
            // If no rows are returned, login failed
            echo "Invalid username/email.";
        }

        // Close connection
        $conn->close();
    }
}
?>
