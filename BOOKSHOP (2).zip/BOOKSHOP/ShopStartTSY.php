<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome to the Bookstore</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php
    session_start();

    // Check if the user is logged in
    if (isset($_SESSION['username'])) {
        // User is logged in, display the header and content
        echo "<header>
                <h1>The Happy Community Library</h1>
                <h3>Welcome to the library</h3>
            </header>
            <article>
                <img src='lib.jpeg' alt='Library Image'> 
                <p>Explore the world of knowledge!<br>
                Discover new adventures within books!<br></p>
            </article>
            <footer>
                <nav>
                    <ul>
                        <li><a href='shopView.php'>View books</a></li>
                        <li><a href='shopAdd.php'>Add a book</a></li>
                        <li><a href='shopDelete.php'>Delete a book</a></li>
                        <li><a href='viewUsers.php'>View Users</a></li>
                        <li><a href='addReviews.php'>Add Reviews</a></li>
                        <li><a href='viewReviews.php'>View Reviews</a></li>
                    </ul>
                </nav>
                
                <h3><a href='login.php'>LOG OUT</a></h3> 
                <h6>Terrence,Yann and Revas Project</h6>
            </footer>";
    } else {
        // User is not logged in, display the login form
        echo "<header>
                <h1>The Happy Community Library</h1>
                <h3>Welcome to the library</h3>
            </header>
            <article>
            <img src='lib.jpeg' alt='Library Image'> 
        <p> Explore the world of knowledge!<br>
            Discover new adventures within books!<br></p>
        </article>
            <footer>
                <nav>
                    <ul>
                        <li><a href='shopView.php'>View books</a></li>
                        <li><a href='shopAdd.php'>Add a book</a></li>
                        <li><a href='shopDelete.php'>Delete a book</a></li>
                        <li><a href='viewUsers.php'>View Users</a></li>
                        <li><a href='addReviews.php'>Add Reviews</a></li>
                        <li><a href='viewReviews.php'>View Reviews</a></li>
                    </ul>
                </nav>
                <h6>Terrence, Yann and Revas Project</h6>
                <h5><a href='login.php'>LOG OUT</a></h5> 
            </footer>";
    }
    ?>
</body>
</html>
