<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Users</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>View Users</h1>
    </header>

    <main>
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Password</th>
                    <th>Email</th> 
                </tr>
            </thead>
            <tbody>
                <?php
                
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "bookstore_db";

                // Create connection
                $conn = new mysqli($servername, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Query to select users
                $sql = "SELECT * FROM users";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Output data of each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["username"] . "</td>";
                        echo "<td>" . $row["password"] . "</td>";
                        echo "<td>" . $row["email"] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>No users found</td></tr>";
                }
                $conn->close();
                ?>
            </tbody>
        </table>
    </main>

    <footer>
        <nav>
            <ul>
                <li><a href="shopStartTSY.php">Main page</a></li>
                <li><a href="shopView.php">View books</a></li>
                <li><a href="shopAdd.php">Add a book</a></li>
                <li><a href="shopDelete.php">Delete a book</a></li>
                <li><a href="addReviews.php">Add reviews</a></li>
                <li><a href="viewReviews.php">View reviews</a></li>
            </ul>
        </nav>
        <h6>Terrence, Yann and Revas Project</h6>
        <h5><a href="login.php">LOG OUT</a></h5> 
    </footer>
</body>
</html>
