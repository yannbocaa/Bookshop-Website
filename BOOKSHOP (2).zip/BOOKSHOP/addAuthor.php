<?php
// Database connection parameters
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "bookstore_db"; 
// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $author_name = $_POST["author_name"];
    $birth_date = $_POST["birth_date"];
    $nationality = $_POST["nationality"];
    $biography = $_POST["biography"];

    // SQL query to insert new author into authors table
    $sql = "INSERT INTO authors (author_name, birth_date, nationality, biography) VALUES ('$author_name', '$birth_date', '$nationality', '$biography')";

    if ($conn->query($sql) === TRUE) {
        echo "New author added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Author</title>
</head>
<body>

<h2>Add New Author</h2>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    Author Name: <input type="text" name="author_name"><br><br>
    Birth Date: <input type="date" name="birth_date"><br><br>
    Nationality: <input type="text" name="nationality"><br><br>
    Biography: <textarea name="biography"></textarea><br><br>
    <input type="submit" value="Add Author">
</form>
<footer>
        <nav>
            <ul>
            <li><a href="ShopStartTSY.php">Home</a></li>
                <li><a href="shopView.php">View Books</a></li>
                <li><a href="shopAdd.php">Add a Book</a></li>
                <li><a href="shopDelete.php">Delete a Book</a></li>
                <li><a href="viewUsers.php">View Users</a></li>
                <li><a href="addReviews.php">Add reviews</a></li>
                <li><a href="viewReviews.php">View reviews</a></li>
                <li><a href="viewAuthors.php"></a>View Authors</li>
            </ul>
        </nav>
</body>
</html>
