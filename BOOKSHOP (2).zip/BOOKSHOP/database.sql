-- CREATE DATABASE bookstore_db;

/*CREATE TABLE bookstore_db.books(
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    genre VARCHAR(100),
    publication_year INT
);*/

/*CREATE TABLE bookstore_db.users(
    username varchar(255),
    password varchar(255),
    email varchar(255)
);*/

-- ALTER TABLE bookstore_db.users 
-- ADD COLUMN id INT AUTO_INCREMENT PRIMARY KEY FIRST;

/*CREATE TABLE bookstore_db.reviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    book_id INT,
    rating INT,
    comment TEXT
);*/
/*CREATE TABLE bookstore_db.book_reviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    book_id INT NOT NULL,
    rating INT NOT NULL,
    comment TEXT
);
);*/

