<?php
// Database connection parameters
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "bookstore_db"; 

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if username, password, and email are provided
    if (isset($_POST['username']) && isset($_POST['password']) && isset($_POST['email'])) {
        // Hash the password
        $hashed_password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Prepare SQL statement to insert user information into the database
        $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);

        // Bind parameters and execute the statement
        $stmt->bind_param("sss", $_POST['username'], $_POST['email'], $hashed_password);
        $result = $stmt->execute();

        // Check if registration was successful
        if ($result === TRUE) {
            echo "<p class='success'>Registration successful! You can now <a href='shopStartTSY.php'>login</a>.</p>";
        } else {
            echo "<p class='error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
        }

        // Close the prepared statement and database connection
        $stmt->close();
        $conn->close();
    } else {
        echo "<p class='error'>Username, password, and email are required.</p>";
    }
}
?>
