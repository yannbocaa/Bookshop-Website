
<?php
$nav = '<nav><ul>';
$nav .= '<li><a href="shopStart.php"> Main page</a></li> ';
$nav .= '<li><a href="shopView.php">View books</a></li> ';
$nav .= '<li><a href="shopAdd.php">Add a book</a></li> ';
$nav .= '<li><a href="shopDelete.php">Delete a book</a></li> ';
$nav .= '<li><a href="addReviews.php">Add Review</a></li> ';
$nav .= '<li><a href="viewReviews.php">View Reviews</a></li> ';
$nav .= '</ul></nav>';
echo $nav;
?>