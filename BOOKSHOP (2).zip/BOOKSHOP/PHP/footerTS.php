<?php include 'nav.php'; ?>
<?php
$footer='<h6>Terrence, Yann and Revas Project<h6> <br>';
$footer .= ' <h5><a href="login.php">LOG OUT</a></h5>';
echo $footer;
?>