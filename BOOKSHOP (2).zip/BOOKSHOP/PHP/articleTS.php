<?php
$article='Explore the world of knowledge!<br>';
$article=' Discover new adventures within books!br>';
$article='Happy Reading<br>';
echo $article;
?>