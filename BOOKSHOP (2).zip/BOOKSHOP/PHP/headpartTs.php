<?php 
$headpartTs = '<title>Community Library</title>';
$headpartTs .= '<meta charset="UTF-8">';
$headpartTs .= '<link rel="stylesheet" type="text/css" href="style.css">';
echo $headpartTs;
?>
