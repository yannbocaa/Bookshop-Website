<?php 
    session_start();
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Database connection parameters
        $servername = "localhost"; 
        $username = "root"; 
        $password = ""; 
        $dbname = "bookstore_db"; 

        //Retrieving Data
        $user_id = $_SESSION['user_id'];
        $book_id = $_POST['book_id'];
        $rating = intval($_POST['rating']);
        $comment = $_POST['comment'];

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Perform SQL query to insert review into the database
        $sql = "INSERT INTO bookstore_db.book_reviews (user_id, book_id, rating, comment) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        //Bind the parameters and execute the statement
        $stmt->bind_param("iiss", $user_id, $book_id, $rating, $comment);
        $result = $stmt->execute();

        // Check if the insertion was successful
        if ($result === TRUE) {
            echo "<p class='success'>New review added successfully! YOU CAN SEE THE  <a href='viewReviews.php'>REVIEWS</a></p>";
        } else {
            echo "<p class='error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
        }

        // Close the prepared statement and database connection
        $stmt->close();
        $conn->close();
    }
?>
