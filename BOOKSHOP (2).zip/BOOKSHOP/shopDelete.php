<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Delete a Book</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>The Happy Community Library</h1>
        <h3>Delete a Book</h3>
    </header>

    <main>
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "bookstore_db";

            if (isset($_POST['book_id'])) {
                $conn = new mysqli($servername, $username, $password, $dbname);

                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                $sql = "DELETE FROM books WHERE id = ?";
                $stmt = $conn->prepare($sql);

                $stmt->bind_param("i", $_POST['book_id']);
                $result = $stmt->execute();

                if ($result === TRUE) {
                    echo "<p class='success'>Book deleted successfully!</p>";
                } else {
                    echo "<p class='error'>Error: " . $sql . "<br>" . $conn->error . "</p>";
                }

                $stmt->close();
                $conn->close();
            } else {
                echo "<p class='error'>No book ID provided.</p>";
            }
        }
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <label for="book_id">Enter the ID of the book to delete:</label><br>
            <input type="number" id="book_id" name="book_id" required><br><br>

            <input type="submit" value="Delete Book">
        </form>
    </main>

    <footer>
        <nav>
            <ul>
            <li><a href="ShopStartTSY.php">Home</a></li>
                <li><a href="shopView.php">View Books</a></li>
                <li><a href="shopAdd.php">Add a Book</a></li>
                <li><a href="shopDelete.php">Delete a Book</a></li>
                <li><a href="viewUsers.php">View Users</a></li>
                <li><a href="addReviews.php">Add reviews</a></li>
                <li><a href="viewReviews.php">View reviews</a></li>
            </ul>
        </nav>
        <h6>Terrence, Yann and Revas Project</h6>
        <h5><a href="login.php">LOG OUT</a></h5> 
    </footer>
</body>
</html>
