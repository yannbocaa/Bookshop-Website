<?php
// Database connection parameters
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "bookstore_db"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to fetch authors
$sql = "SELECT * FROM authors";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
    <title>View Authors</title>
</head>
<body>

<h2>Authors List</h2>

<?php
if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<h3>Author ID: " . $row["author_id"]. "</h3>";
        echo "<p>Name: " . $row["author_name"]. "</p>";
        echo "<p>Birth Date: " . $row["birth_date"]. "</p>";
        echo "<p>Nationality: " . $row["nationality"]. "</p>";
        echo "<p>Biography: " . $row["biography"]. "</p>";
        echo "<hr>";
    }
} else {
    echo "0 results";
}

// Close connection
$conn->close();
?>
 <footer>
        <nav>
            <ul>
            <li><a href="ShopStartTSY.php">Home</a></li>
                <li><a href="shopView.php">View Books</a></li>
                <li><a href="shopAdd.php">Add a Book</a></li>
                <li><a href="shopDelete.php">Delete a Book</a></li>
                <li><a href="viewUsers.php">View Users</a></li>
                <li><a href="addReviews.php">Add reviews</a></li>
                <li><a href="viewReviews.php">View reviews</a></li>
            </ul>
        </nav>
        <h6>Terrence, Yann and Revas Project</h6>
        <h5><a href="login.php">LOG OUT</a></h5> 
    </footer>
</body>
</html>
