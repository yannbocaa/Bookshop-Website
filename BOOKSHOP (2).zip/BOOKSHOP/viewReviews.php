<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book Reviews</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1>The Happy Community Library</h1>
        <h3>Book Reviews</h3>
    </header>
    <article>
        <!-- Display book reviews here -->
        <?php
        // Include database connection file
        require_once 'db_connection.php';

        // Fetch book reviews from the database
        $sql = "SELECT * FROM book_reviews";
        $result = mysqli_query($conn, $sql);

        // Check if there are any reviews
        if (mysqli_num_rows($result) > 0) {
            // Display reviews
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<div class='review'>";
                echo "<h2>" . $row['book_title'] . "</h2>";
                echo "<p><strong>Reviewer:</strong> " . $row['reviewer_name'] . "</p>";
                echo "<p><strong>Rating:</strong> " . $row['rating'] . "/5</p>";
                echo "<p><strong>Review:</strong><br>" . $row['review_text'] . "</p>";
                echo "</div>";
            }
        } else {
            // No reviews found
            echo "<p>No reviews found.</p>";
        }

        // Close database connection
        mysqli_close($conn);
        ?>
    </article>
    <footer>
        <nav>
            <ul>
                <li><a href="ShopStartTSY.php">Home</a></li>
                <li><a href="shopView.php">View Books</a></li>
                <li><a href="shopAdd.php">Add a Book</a></li>
                <li><a href="shopDelete.php">Delete a Book</a></li>
                <li><a href="viewUsers.php">View Users</a></li>
                <li><a href="addReviews.php">Add Reviews</a></li>
            </ul>
        </nav>
        <h6>Terrence, Yann and Revas Project</h6>
        <h5><a href="login.php">LOG OUT</a></h5> 
    </footer>
</body>
</html>
